using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace DemoApp.Views;

public partial class PartnersView : UserControl
{
    public PartnersView()
    {
        InitializeComponent();
    }
}