﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace DemoApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
